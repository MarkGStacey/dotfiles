# Astro + Vue scaffold checklist

Use this checklist when starting a new Astro + Vue project.

## 1. Classify the project
- Content site
- Docs site
- Marketing site
- Ecommerce front-end
- SaaS/app shell
- Hybrid

## 2. Pick rendering mode
- Static by default
- Server/hybrid only when needed

## 3. Add integrations deliberately
Common options:
- `@astrojs/vue`
- `@astrojs/mdx`
- `@astrojs/sitemap`
- deployment adapter (`@astrojs/vercel`, `@astrojs/netlify`, etc.)

## 4. Create minimal file structure
- `src/pages`
- `src/layouts`
- `src/components`
- `src/content`
- `src/styles`
- `src/lib` or `src/utils`
- `src/composables` only if Vue logic warrants it
- `src/stores` only if shared state warrants it

## 5. Decide hydration boundaries
For each interactive feature, answer:
- Can this be static in Astro?
- If interactive, does it need `client:load`, `client:idle`, or `client:visible`?

## 6. Add metadata support
- Layout-level SEO props
- Canonical URL helper
- Open Graph image support
- JSON-LD helper if needed

## 7. Add content collections if content is repeatable
- Define schema in `content.config.ts`
- Keep frontmatter validated
- Prefer Markdown over MDX unless embedded components are needed

## 8. Review a11y and performance before shipping
- Heading structure
- Form labels
- Focus behavior
- Image sizes
- Hydration count
- Client bundle weight
