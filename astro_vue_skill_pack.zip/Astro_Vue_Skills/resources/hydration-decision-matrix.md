# Hydration decision matrix for Astro + Vue

## Default priority
1. No hydration
2. `client:visible`
3. `client:idle`
4. `client:load`

## Use no hydration when
- The UI is static
- Simple details/summary or native HTML behavior is enough
- Content can be rendered fully on the server/build

## Use `client:visible` when
- The widget is below the fold
- Initial interaction is not required immediately
- Search/filter widgets can wait until scrolled into view

## Use `client:idle` when
- The widget enhances the page but is not critical
- It is above the fold but not immediately used
- You want to reduce main-thread competition at load time

## Use `client:load` when
- The control must work immediately on page load
- It is a primary navigation/search/account widget
- Delayed interactivity would noticeably harm UX

## Red flags
- Many components using `client:load`
- Layout/header/footer built as Vue without need
- Client-fetching content that was already known at build time
- Whole pages mounted as Vue apps for simple marketing/docs content
