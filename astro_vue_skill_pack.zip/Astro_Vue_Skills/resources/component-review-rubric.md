# Component review rubric

Use this when auditing an Astro + Vue codebase.

## For every Astro component
- Is this truly static or could it be simplified further?
- Does it belong in a layout, section, or primitive layer?
- Is metadata handled at the page/layout level instead of buried in component code?

## For every Vue component
- Does it require client state?
- Could part of it be moved into an Astro shell?
- Is the hydration directive justified?
- Are props explicit and minimal?
- Is state local unless sharing is necessary?
- Is the component keyboard accessible?

## For every composable
- Is it reused enough to justify extraction?
- Does it hide too much complexity?
- Is browser-only logic guarded properly?

## For stores
- Is Pinia genuinely needed?
- Would prop drilling or a parent island be simpler?

## For content
- Should this live in content collections instead of components?
- Is MDX being used only where component embedding is needed?
